---
name: coding-standards
description: 定义项目编码规范基线，涵盖命名、可读性、不可变性和设计原则。指导代码审查和重构，强制执行 KISS、DRY、YAGNI 等原则。
---

# 编码规范

定义项目编码规范基线，涵盖命名约定、可读性标准、不可变性原则和核心设计原则。

## 触发场景

- 进行代码审查时检查规范合规性
- 重构代码时应用统一标准
- 新项目初始化时建立编码规范
- 团队讨论代码风格时作为参考依据

## 命名规范

### 变量与函数
- 使用描述性名称，避免缩写（`userData` 而非 `ud`）
- 布尔变量使用 `is`、`has`、`can` 前缀（`isActive`、`hasPermission`）
- 函数名使用动词开头（`getUser`、`calculateTotal`）
- 常量使用 UPPER_SNAKE_CASE（`MAX_RETRY_COUNT`）

### 文件与组件
- 组件文件使用 PascalCase（`UserProfile.tsx`）
- Hook 文件使用 camelCase（`useAuth.ts`）
- 工具函数文件使用 camelCase（`formatDate.ts`）
- 测试文件与被测文件同名加 `.test` 后缀

## 核心设计原则

### KISS（保持简单）
- 优先选择最简单的解决方案
- 避免过度抽象和过早优化
- 函数长度控制在 30 行以内

### DRY（不要重复）
- 提取重复逻辑为共享函数或组件
- 使用配置文件管理重复的常量值
- 但允许合理的重复以避免过度耦合

### YAGNI（你不会需要它）
- 不为假设的未来需求编写代码
- 只在实际需要时添加抽象层
- 删除未使用的代码和依赖

## 不可变性

- 使用 `const` 声明变量，避免 `let`
- 对象更新使用展开运算符：`{ ...state, key: value }`
- 数组操作使用 `map`、`filter`、`reduce` 而非 `push`、`splice`
- 避免直接修改函数参数

## 错误处理

- 所有异步操作必须包含 try-catch
- 错误信息要具体，包含上下文（文件名、行号、操作）
- 使用自定义错误类型区分错误类别
- 不要在 catch 中吞掉错误，至少记录日志

## 类型安全

- 避免使用 `any` 类型
- 为 API 响应定义明确的接口
- 使用 Zod 或类似库进行运行时验证
- 泛型参数要有意义地命名

## 异步模式

- 使用 `Promise.all` 并行执行独立异步操作
- 使用 `async/await` 而非 `.then()` 链
- 设置合理的超时时间
- 处理竞态条件

## REST API 响应结构

```typescript
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
  };
  meta?: {
    page: number;
    total: number;
  };
}
```

## 项目结构

```
src/
  app/          # 路由和页面
  components/   # 可复用组件
  hooks/        # 自定义 Hook
  utils/        # 工具函数
  types/        # 类型定义
  services/     # API 服务层
  __tests__/    # 测试文件
```
