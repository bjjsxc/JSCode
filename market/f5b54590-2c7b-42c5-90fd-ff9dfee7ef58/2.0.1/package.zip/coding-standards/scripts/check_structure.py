#!/usr/bin/env python3
"""项目结构规范检查工具。

验证项目目录结构是否符合编码规范，包括：
- 必需目录是否存在
- 文件命名是否符合约定（PascalCase 组件、camelCase 工具函数）
- 测试文件是否与被测文件配对
"""

import os
import re
import sys
from pathlib import Path


REQUIRED_DIRS = ["src/app", "src/components", "src/hooks", "src/utils", "src/types", "src/services"]

PASCAL_CASE = re.compile(r"^[A-Z][a-zA-Z0-9]*\.tsx?$")
CAMEL_CASE = re.compile(r"^[a-z][a-zA-Z0-9]*\.ts$")
TEST_FILE = re.compile(r"^.+\.test\.tsx?$")


def check_dir_structure(root: Path) -> list[str]:
    errors = []
    for d in REQUIRED_DIRS:
        if not (root / d).is_dir():
            errors.append(f"缺少必需目录: {d}/")
    return errors


def check_file_naming(root: Path) -> list[str]:
    errors = []
    components_dir = root / "src" / "components"
    if components_dir.is_dir():
        for f in components_dir.rglob("*.tsx"):
            if not PASCAL_CASE.match(f.name):
                errors.append(f"组件文件应使用 PascalCase: {f.relative_to(root)}")

    utils_dir = root / "src" / "utils"
    if utils_dir.is_dir():
        for f in utils_dir.rglob("*.ts"):
            if not CAMEL_CASE.match(f.name) and not TEST_FILE.match(f.name):
                errors.append(f"工具函数文件应使用 camelCase: {f.relative_to(root)}")

    hooks_dir = root / "src" / "hooks"
    if hooks_dir.is_dir():
        for f in hooks_dir.rglob("*.ts"):
            if not f.name.startswith("use") and not TEST_FILE.match(f.name):
                errors.append(f"Hook 文件应以 use 开头: {f.relative_to(root)}")

    return errors


def check_test_pairing(root: Path) -> list[str]:
    errors = []
    src_dir = root / "src"
    if not src_dir.is_dir():
        return errors

    for f in src_dir.rglob("*.ts"):
        if f.name.endswith(".test.ts"):
            source = f.with_name(f.name.replace(".test.ts", ".ts"))
            source_tsx = f.with_name(f.name.replace(".test.ts", ".tsx"))
            if not source.exists() and not source_tsx.exists():
                errors.append(f"测试文件缺少对应源文件: {f.relative_to(root)}")

    return errors


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    print(f"检查项目结构: {root}\n")

    all_errors = []
    all_errors.extend(check_dir_structure(root))
    all_errors.extend(check_file_naming(root))
    all_errors.extend(check_test_pairing(root))

    if all_errors:
        print(f"发现 {len(all_errors)} 个问题:\n")
        for e in all_errors:
            print(f"  ✗ {e}")
        return 1
    else:
        print("✓ 项目结构符合规范")
        return 0


if __name__ == "__main__":
    sys.exit(main())
