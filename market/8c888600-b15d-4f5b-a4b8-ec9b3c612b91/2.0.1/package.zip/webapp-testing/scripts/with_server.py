#!/usr/bin/env python3
"""测试服务器生命周期管理工具。

在子进程中启动一个或多个开发服务器，等待端口就绪后执行测试命令，
最后自动清理所有服务器进程。

用法:
    python with_server.py --server "npm run dev" --port 5173 -- python test.py
    python with_server.py --server "npm run api" --port 3000 --server "npm run dev" --port 5173 -- python test.py
    python with_server.py --help
"""

import argparse
import socket
import subprocess
import sys
import time
import signal
import os


def wait_for_port(port: int, host: str = "127.0.0.1", timeout: float = 30.0) -> bool:
    """等待端口就绪，超时返回 False。"""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=1):
                return True
        except (ConnectionRefusedError, OSError):
            time.sleep(0.3)
    return False


def main() -> int:
    parser = argparse.ArgumentParser(
        description="启动服务器 → 等待就绪 → 执行命令 → 清理进程"
    )
    parser.add_argument(
        "--server", action="append", required=True,
        help="服务器启动命令（可多次指定）"
    )
    parser.add_argument(
        "--port", action="append", required=True, type=int,
        help="对应服务器的端口（与 --server 一一对应）"
    )
    parser.add_argument(
        "--timeout", type=float, default=30.0,
        help="等待端口就绪的超时秒数（默认 30）"
    )
    parser.add_argument(
        "--host", default="127.0.0.1",
        help="等待连接的主机地址（默认 127.0.0.1）"
    )
    parser.add_argument(
        "command", nargs="+",
        help="服务器就绪后要执行的命令"
    )

    args = parser.parse_args()

    if len(args.server) != len(args.port):
        parser.error("--server 和 --port 的数量必须匹配")

    servers: list[subprocess.Popen] = []
    cmd_str = " ".join(args.command)

    try:
        for srv_cmd, port in zip(args.server, args.port):
            print(f"[with_server] 启动: {srv_cmd} (端口 {port})")
            if sys.platform == "win32":
                proc = subprocess.Popen(
                    srv_cmd, shell=True,
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
                )
            else:
                proc = subprocess.Popen(
                    srv_cmd, shell=True,
                    preexec_fn=os.setsid
                )
            servers.append(proc)

        for port in args.port:
            print(f"[with_server] 等待端口 {port} 就绪...")
            if not wait_for_port(port, args.host, args.timeout):
                print(f"[with_server] 错误: 端口 {port} 在 {args.timeout}s 内未就绪", file=sys.stderr)
                return 1
            print(f"[with_server] 端口 {port} 已就绪")

        print(f"[with_server] 执行: {cmd_str}")
        result = subprocess.run(args.command)
        return result.returncode

    finally:
        print("[with_server] 清理服务器进程...")
        for proc in servers:
            try:
                if sys.platform == "win32":
                    proc.send_signal(signal.CTRL_BREAK_EVENT)
                else:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except (ProcessLookupError, OSError):
                pass
            proc.wait(timeout=5)
        print("[with_server] 清理完成")


if __name__ == "__main__":
    sys.exit(main())
