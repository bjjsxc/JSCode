---
name: webapp-testing
description: 使用原生 Python Playwright 脚本测试本地 Web 应用，支持服务器生命周期管理、动态内容识别和自动化操作。
---

# Web 应用自动化测试

使用原生 Python Playwright 脚本对本地 Web 应用进行端到端测试，内置服务器生命周期管理。

## 触发场景

- 需要对本地运行的 Web 应用进行自动化测试
- 需要验证 UI 交互流程和页面状态
- 需要捕获控制台日志和页面截图
- 需要管理测试服务器的启动和关闭

## 核心工作流

### 1. 服务器管理

使用 `scripts/with_server.py` 辅助脚本管理测试服务器：

```bash
# 启动单个服务器
python scripts/with_server.py --server "npm run dev" --port 5173 -- python your_automation.py

# 启动多个服务器
python scripts/with_server.py --server "npm run api" --port 3000 --server "npm run dev" --port 5173 -- python your_automation.py
```

始终先运行 `--help` 查看可用选项。将这些脚本视为黑盒使用，无需将其源码载入上下文。

### 2. 侦察-再行动工作流

对于动态 Web 应用，遵循以下步骤：

1. **导航**：打开目标页面
2. **等待**：等待 `networkidle` 状态，防止时序错误
3. **侦察**：截图或检查 DOM，识别选择器
4. **行动**：执行自动化操作

### 3. 静态 HTML 处理

如果应用是静态 HTML，直接读取 HTML 文件查找选择器，无需启动服务器。

## 关键原则

- 始终等待 `networkidle` 后再检查页面状态
- 优先使用语义化选择器（role、label）而非 CSS/XPath
- 对动态内容使用显式等待而非硬编码延迟
- 测试结束后清理服务器进程

## 示例

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page()
    page.goto("http://localhost:5173")
    page.wait_for_load_state("networkidle")
    # 截图侦察
    page.screenshot(path="initial.png")
    # 执行操作
    page.click("button:has-text('提交')")
    page.wait_for_load_state("networkidle")
    browser.close()
```
