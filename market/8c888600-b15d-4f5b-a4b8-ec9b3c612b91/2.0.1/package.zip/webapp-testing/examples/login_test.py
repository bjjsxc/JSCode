"""示例：使用侦察-再行动工作流测试 Web 应用。

运行方式:
    python scripts/with_server.py --server "npm run dev" --port 5173 -- python examples/login_test.py
"""

from playwright.sync_api import sync_playwright, expect


def test_login_flow(base_url: str = "http://localhost:5173"):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            viewport={"width": 1280, "height": 720},
            locale="zh-CN",
        )
        page = context.new_page()

        # 1. 导航
        page.goto(base_url)
        page.wait_for_load_state("networkidle")

        # 2. 侦察：截图确认页面加载
        page.screenshot(path="screenshots/01-landing.png")
        print("[测试] 页面已加载")

        # 3. 行动：使用语义化定位器填写表单
        page.get_by_role("link", name="登录").click()
        page.wait_for_load_state("networkidle")

        page.get_by_label("邮箱").fill("test@example.com")
        page.get_by_label("密码").fill("password123")
        page.get_by_role("button", name="登录").click()

        # 4. 验证结果
        page.wait_for_url("**/dashboard")
        expect(page.get_by_text("欢迎")).to_be_visible(timeout=5000)
        page.screenshot(path="screenshots/02-dashboard.png")
        print("[测试] 登录成功 ✓")

        browser.close()


if __name__ == "__main__":
    test_login_flow()
