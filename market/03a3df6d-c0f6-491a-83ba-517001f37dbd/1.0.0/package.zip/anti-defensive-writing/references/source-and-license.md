# 来源与许可

- 原项目：[Kiterlin/anti-defensive-writing](https://github.com/Kiterlin/anti-defensive-writing)。
- 原作者：Kiterlin；上游说明另署 Sunlight and Contributors。
- 对应上游提交：`c7edf8fc91ae9c4f7e58345bd12934bb4cf41c46`。
- 原始技能：[固定版本 SKILL.md](https://github.com/Kiterlin/anti-defensive-writing/blob/c7edf8fc91ae9c4f7e58345bd12934bb4cf41c46/SKILL.md)。
- 上游许可：[MIT License](https://github.com/Kiterlin/anti-defensive-writing/blob/c7edf8fc91ae9c4f7e58345bd12934bb4cf41c46/LICENSE)。
- 中文整理版本：1.0.0；整理日期：2026-10-13。

本版本采用上游已有的完整中文核心规则和扩充规则，补齐中文元数据、展示名称、使用提示和来源说明，并调整标题层级。核心写作原则与事实边界保持上游含义。英文稿件的示例保留英文，以便直接对照使用。

MIT 许可允许复制、修改和分发；分发时须保留原作者版权声明和许可文本。包内 [LICENSE](../LICENSE) 保留上游原文，中文说明不替代许可原文。
