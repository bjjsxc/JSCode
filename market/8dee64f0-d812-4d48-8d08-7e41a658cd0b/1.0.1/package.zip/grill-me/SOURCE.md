# 来源说明

- 技能：拷问我（grill-me）
- 原作者：Matt Pocock
- 仓库：https://github.com/mattpocock/skills
- 来源提交：3cca18b368ae95cdbdebbff572ccafa662551015
- 入口：skills/productivity/grill-me/SKILL.md
- 核心：skills/productivity/grilling/SKILL.md
- 许可：MIT，原始版权与许可全文保留在 LICENSE。
- 内部包版本：1.0.1，与上游 Git 提交独立记录。
- 打包调整：入口内联上游 grilling 的完整正文以消除跨技能调用依赖；描述改为中文，保留原有显式调用策略及核心提问规则。

- 中文适配：肖志伟。正文、提问模板及界面名称汉化，默认使用简体中文；保留上游按轮次推进、依赖顺序、事实调查及共识确认规则。
