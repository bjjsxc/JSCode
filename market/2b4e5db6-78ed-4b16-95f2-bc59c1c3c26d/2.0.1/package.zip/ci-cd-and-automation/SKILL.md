---
name: ci-cd-and-automation
description: 自动化 CI/CD 流水线，通过质量门禁确保代码在到达生产环境前通过所有检查。支持 GitHub Actions、预览部署和分阶段发布。
---

# CI/CD 与自动化流水线

自动化 CI/CD 流水线，通过质量门禁确保代码质量，推行"左移"策略尽早发现缺陷。

## 触发场景

- 搭建新项目的 CI/CD 流水线
- 修改或调试自动化检查流程
- 配置预览部署或分阶段发布
- 设置依赖自动更新和安全审计

## 质量门禁流水线

按顺序执行以下检查步骤：

1. **代码检查（Lint）**：代码风格和静态分析
2. **类型检查**：TypeScript 类型验证
3. **单元测试**：核心逻辑测试
4. **构建**：编译和打包
5. **集成测试**：模块间交互测试
6. **E2E 测试**（可选）：端到端用户流程测试
7. **安全审计**：依赖漏洞扫描
8. **包体积检查**：防止包体积异常增长

## GitHub Actions 配置

### 基础 CI

```yaml
name: CI
on: [push, pull_request]
jobs:
  quality-gate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npm run lint
      - run: npm run type-check
      - run: npm test
      - run: npm run build
```

### 数据库集成测试

```yaml
  integration:
    needs: quality-gate
    services:
      postgres:
        image: postgres:16
        env:
          POSTGRES_DB: test_db
          POSTGRES_PASSWORD: test
        ports: ['5432:5432']
    steps:
      - run: npm run test:integration
```

### E2E 测试（Playwright）

```yaml
  e2e:
    needs: integration
    steps:
      - run: npx playwright install --with-deps
      - run: npm run test:e2e
```

## 部署策略

### 预览部署
为每个 PR 创建独立的预览环境，方便代码审查时实时验证。

### 特性开关
使用特性开关控制新功能上线，支持灰度发布和快速回滚。

### 分阶段发布
- 第一阶段：内部测试环境（5% 流量）
- 第二阶段：金丝雀发布（20% 流量）
- 第三阶段：全面发布（100% 流量）

## CI 优化技巧

- 使用依赖缓存加速安装（`actions/cache`）
- 并行执行独立测试任务
- 增量测试：只运行受变更影响的测试
- 使用 Dependabot 自动管理依赖更新
- 设置"构建值班"角色处理 CI 失败

## 回滚机制

- 保留最近 5 个部署版本
- 支持一键回滚到任意历史版本
- 自动监控部署后错误率，超阈值触发告警
