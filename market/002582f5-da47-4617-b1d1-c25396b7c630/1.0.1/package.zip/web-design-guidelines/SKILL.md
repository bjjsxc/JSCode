---
name: web-design-guidelines
description: 审查 UI 代码是否符合 Web 界面设计规范。当用户要求"审查我的 UI"、"检查无障碍"、"审计设计"、"检查 UX"或"对照最佳实践检查我的网站"时使用。
metadata:
  author: vercel
  version: "1.0.1"
  argument-hint: <文件或路径>
---

# Web 界面设计规范

审查文件是否符合 Web 界面设计规范。

## 工作流程

1. 从下方源地址获取最新规范
2. 读取指定文件（或提示用户输入文件/路径）
3. 对照规范中的所有规则进行检查
4. 以简洁的 `文件:行号` 格式输出问题

## 规范源地址

每次审查前获取最新规范：

```
https://raw.githubusercontent.com/vercel-labs/web-interface-guidelines/main/command.md
```

使用 WebFetch 获取最新规则。获取的内容包含所有规则和输出格式说明。

## 使用方法

当用户提供文件或路径参数时：
1. 从上方源地址获取规范
2. 读取指定文件
3. 应用获取到的规范中的所有规则
4. 按照规范中指定的格式输出问题

如果未指定文件，询问用户要审查哪些文件。
