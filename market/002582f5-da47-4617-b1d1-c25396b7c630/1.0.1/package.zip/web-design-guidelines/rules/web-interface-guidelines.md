---
description: 审查 UI 代码是否符合 Vercel Web 界面设计规范
argument-hint: <文件或路径>
---

# Web 界面设计规范

审查以下文件是否符合规范：$ARGUMENTS

读取文件，对照以下规则检查。输出简洁但全面——为简洁可牺牲语法。高信噪比。

## 规则

### 无障碍

- 纯图标按钮需要 `aria-label`
- 表单控件需要 `<label>` 或 `aria-label`
- 交互元素需要键盘处理器（`onKeyDown`/`onKeyUp`）
- `<button>` 用于操作，`<a>`/`<Link>` 用于导航（不要用 `<div onClick>`）
- 图片需要 `alt`（装饰性图片用 `alt=""`）
- 装饰性图标需要 `aria-hidden="true"`
- 异步更新（提示、验证）需要 `aria-live="polite"`
- 优先使用语义化 HTML（`<button>`、`<a>`、`<label>`、`<table>`），再考虑 ARIA
- 标题层级 `<h1>`–`<h6>`；包含跳转到主内容的链接
- 标题锚点设置 `scroll-margin-top`
- 有意义的媒体内容需要字幕、文字记录或描述
- 媒体控件需要键盘支持；装饰性媒体需要对辅助技术隐藏

### 焦点状态

- 交互元素需要可见焦点：`focus-visible:ring-*` 或等效样式
- 永远不要在没有焦点替代的情况下使用 `outline-none` / `outline: none`
- 使用 `:focus-visible` 而非 `:focus`（避免点击时出现焦点环）
- 使用 `:focus-within` 为复合控件分组焦点
- 粘性页眉/页脚/遮罩不得覆盖焦点元素

### 表单

- 输入框需要 `autocomplete` 和有意义的 `name`
- 使用正确的 `type`（`email`、`tel`、`url`、`number`）和 `inputmode`
- 永远不要阻止粘贴（`onPaste` + `preventDefault`）
- 标签可点击（`htmlFor` 或包裹控件）
- 对邮箱、验证码、用户名禁用拼写检查（`spellCheck={false}`）
- 复选框/单选框：标签和控件共享同一点击区域（无死区）
- 提交按钮在请求开始前保持启用；请求中显示加载动画
- 错误信息内联显示在字段旁；提交时聚焦第一个错误
- 占位符以 `…` 结尾并显示示例格式
- 非认证字段使用 `autocomplete="off"` 避免密码管理器触发
- 未保存更改时导航前警告（`beforeunload` 或路由守卫）

### 动画

- 遵循 `prefers-reduced-motion`（提供减弱版本或禁用）
- 只动画 `transform`/`opacity`（合成器友好）
- 永远不要 `transition: all`——明确列出属性
- 设置正确的 `transform-origin`
- SVG：在 `<g>` 包装器上使用 transforms，配合 `transform-box: fill-box; transform-origin: center`
- 动画可中断——响应用户输入
- 自动播放超过 5 秒的动态内容需提供暂停、停止或隐藏控制
- 静音装饰性循环必须在 `prefers-reduced-motion` 下停止

### 排版

- 使用 `…` 而非 `...`
- 使用弯引号 `"` `"` 而非直引号 `"`
- 不换行空格：`10&nbsp;MB`、`⌘&nbsp;K`、品牌名称
- 加载状态以 `…` 结尾：`"加载中…"`、`"保存中…"`
- 数字列/对比使用 `font-variant-numeric: tabular-nums`
- 标题使用 `text-wrap: balance` 或 `text-pretty`（防止孤字）

### 内容处理

- 文本容器处理长内容：`truncate`、`line-clamp-*` 或 `break-words`
- Flex 子元素需要 `min-w-0` 以允许文本截断
- 处理空状态——不要为空字符串/数组渲染破损 UI
- 用户生成内容：预期短、中等和非常长的输入

### 图片

- `<img>` 需要明确的 `width` 和 `height`（防止 CLS）
- 折叠下方图片：`loading="lazy"`
- 首屏关键图片：`priority` 或 `fetchpriority="high"`

### 性能

- 大列表（>50 项）：虚拟化（`virtua`、`content-visibility: auto`）
- 不要在渲染中读取布局（`getBoundingClientRect`、`offsetHeight`、`offsetWidth`、`scrollTop`）
- 批量 DOM 读写；避免交替操作
- 优先使用非受控输入；受控输入必须保证每次按键开销低
- 为 CDN/资源域名添加 `<link rel="preconnect">`
- 关键字体：`<link rel="preload" as="font">` 配合 `font-display: swap`
- 优先使用 `<video autoplay muted loop playsinline>` 而非 GIF；提供静态备选
- 短非关键循环：Safari H.264 MP4 `<picture>` 源、`prefers-reduced-motion` 媒体条件和静态回退

### 导航与状态

- URL 反映状态——筛选、标签、分页、展开面板在查询参数中
- 链接使用 `<a>`/`<Link>`（支持 Cmd/Ctrl+点击、中键点击）
- 所有有状态 UI 支持深链接（如果使用 `useState`，考虑通过 nuqs 等同步到 URL）
- 破坏性操作需要确认弹窗或撤销窗口——永不立即执行

### 触摸与交互

- `touch-action: manipulation`（防止双击缩放延迟）
- 有意设置 `-webkit-tap-highlight-color`
- 模态框/抽屉/表单中使用 `overscroll-behavior: contain`
- 拖拽时：禁用文本选择，被拖拽元素使用 `inert`
- 拖拽/滑动/捏合/路径手势需要点击和键盘替代方案（除非必需）
- 谨慎使用 `autoFocus`——仅限桌面端、单一主要输入；避免在移动端使用

### 安全区域与布局

- 全屏布局需要 `env(safe-area-inset-*)` 适配刘海
- 避免不必要的滚动条：容器使用 `overflow-x-hidden`，修复内容溢出
- 使用 Flex/grid 而非 JS 测量布局

### 深色模式与主题

- 深色主题在 `<html>` 上设置 `color-scheme: dark`（修复滚动条、输入框）
- `<meta name="theme-color">` 匹配页面背景
- 原生 `<select>`：明确设置 `background-color` 和 `color`（Windows 深色模式）

### 本地化与国际化

- 日期/时间：使用 `Intl.DateTimeFormat` 而非硬编码格式
- 数字/货币：使用 `Intl.NumberFormat` 而非硬编码格式
- 通过 `Accept-Language` / `navigator.languages` 检测语言，而非 IP
- 品牌名称、代码标记、标识符：使用 `translate="no"` 防止自动翻译破坏

### 水合安全

- 有 `value` 的输入框需要 `onChange`（或使用 `defaultValue` 非受控）
- 日期/时间渲染：防止水合不匹配（服务端 vs 客户端）
- `suppressHydrationWarning` 仅在真正需要时使用

### 悬停与交互状态

- 按钮/链接需要 `hover:` 状态（视觉反馈）
- 交互状态增加对比度：hover/active/focus 比默认状态更明显

### 内容与文案

- 使用主动语态："安装 CLI"而非"CLI 将被安装"
- 标题/按钮使用标题大小写
- 数量使用数字："8 个部署"而非"八个部署"
- 按钮标签具体明确："保存 API Key"而非"继续"
- 错误信息包含修复/下一步，而非仅描述问题
- 使用第二人称；避免第一人称
- 空间受限时使用 `&` 而非"和"

### 反模式（标记这些问题）

- `user-scalable=no` 或 `maximum-scale=1` 禁用缩放
- `onPaste` 配合 `preventDefault`
- `transition: all`
- `outline-none` 没有 focus-visible 替代
- 内联 `onClick` 导航没有 `<a>`
- `<div>` 或 `<span>` 带点击处理器（应该是 `<button>`）
- 图片没有尺寸
- 大数组 `.map()` 没有虚拟化
- 表单输入没有标签
- 图标按钮没有 `aria-label`
- 硬编码日期/数字格式（使用 `Intl.*`）
- `autoFocus` 没有明确理由
- 适合压缩视频时使用 GIF
- 仅手势操作没有点击/键盘替代

## 输出格式

按文件分组。使用 `文件:行号` 格式（VS Code 可点击）。简洁的问题描述。

```text
## src/Button.tsx

src/Button.tsx:42 - 图标按钮缺少 aria-label
src/Button.tsx:18 - 输入框缺少标签
src/Button.tsx:55 - 动画缺少 prefers-reduced-motion
src/Button.tsx:67 - transition: all → 明确列出属性

## src/Modal.tsx

src/Modal.tsx:12 - 缺少 overscroll-behavior: contain
src/Modal.tsx:34 - "..." → "…"

## src/Card.tsx

✓ 通过
```

陈述问题+位置。除非修复不明显否则跳过解释。无前言。
