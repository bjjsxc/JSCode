---
name: browser-automation
description: 使用语义化定位器和 UI 状态构建可靠的浏览器自动化检查。强调复用已认证浏览器会话，避免脆弱选择器，显式验证操作结果。
---

# 浏览器自动化

使用语义化定位器和 UI 状态构建可靠的浏览器自动化检查，适用于 Web 应用测试、数据采集和流程自动化。

## 触发场景

- 需要自动化浏览器操作（填表、点击、导航）
- 需要验证 Web 应用的 UI 状态和功能
- 需要跨页面执行多步骤工作流
- 需要从 Web 页面提取结构化数据
- 需要定期执行 Web 检查任务

## 核心原则

### 1. 复用已认证浏览器

- 优先使用已有的、已登录的浏览器会话
- 不要每次测试都创建全新的浏览器实例
- 保存和复用浏览器状态（Cookie、LocalStorage）
- 减少重复登录带来的开销和不稳定性

### 2. 语义化定位器优先

避免使用脆弱的 CSS/XPath 选择器：

```
❌ 避免：page.locator('div > div:nth-child(3) > button.btn-primary')
❌ 避免：page.locator('//*[@id="form"]/div[2]/input')

✅ 推荐：page.get_by_role('button', name='提交')
✅ 推荐：page.get_by_label('邮箱地址')
✅ 推荐：page.get_by_text('欢迎回来')
✅ 推荐：page.get_by_placeholder('请输入密码')
```

### 3. 显式验证结果

每个操作后都要验证预期结果：

```python
# 点击后验证页面跳转
page.click("button:has-text('登录')")
page.wait_for_url("**/dashboard")
expect(page.get_by_text("欢迎")).to_be_visible()

# 填表后验证成功消息
page.fill("input[name='email']", "test@example.com")
page.click("button:has-text('提交')")
expect(page.get_by_text("提交成功")).to_be_visible()
```

### 4. 分离受控测试与外部交互

- 应用内部测试：完全控制测试环境
- 外部网站交互：考虑网络波动、页面变化等因素
- 为外部交互添加更长的超时和重试机制

## 可靠自动化模式

### 等待策略

```python
# 等待元素出现
page.wait_for_selector("button:has-text('保存')", state="visible")

# 等待元素消失
page.wait_for_selector(".loading-spinner", state="hidden")

# 等待网络空闲
page.wait_for_load_state("networkidle")

# 等待特定响应
page.wait_for_response("**/api/submit")
```

### 重试机制

```python
from playwright.sync_api import expect

# 自动重试直到条件满足（默认 5 秒超时）
expect(page.get_by_text("加载完成")).to_be_visible(timeout=10000)
```

### 页面导航

```python
# 等待导航完成
page.goto("https://example.com", wait_until="domcontentloaded")

# 等待特定条件后再继续
page.goto("https://example.com")
page.wait_for_load_state("networkidle")
```

## 安全检查清单

执行浏览器自动化前确认：

- [ ] 使用正确的浏览器配置文件（避免污染个人会话）
- [ ] 已处理登录和认证状态
- [ ] 选择器使用语义化定位器
- [ ] 每个操作后有显式验证
- [ ] 设置了合理的超时时间
- [ ] 测试数据不会污染生产环境
- [ ] 自动化脚本有错误处理和日志记录

## 常见问题排查

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| 元素找不到 | 页面未加载完成 | 添加 `wait_for_load_state` |
| 选择器失效 | UI 结构变化 | 改用语义化定位器 |
| 测试偶尔失败 | 时序问题 | 使用显式等待替代 `sleep` |
| 登录状态丢失 | Cookie 过期 | 复用浏览器上下文或重新登录 |
| 弹窗阻塞 | 未处理的对话框 | 使用 `handle_dialog` 处理 |
