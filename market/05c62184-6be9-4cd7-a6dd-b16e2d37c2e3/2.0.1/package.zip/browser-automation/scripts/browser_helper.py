#!/usr/bin/env python3
"""语义化定位器辅助工具。

提供一组封装好的 Playwright 定位器工厂函数，
帮助 Agent 快速构建可靠的浏览器自动化脚本。

使用方式：在自动化脚本中 import 并按需调用。
"""

from playwright.sync_api import Page, BrowserContext, expect
import json
import os


def semantic_locator(page: Page, description: str):
    """根据自然语言描述返回语义化定位器。

    支持的描述格式:
        "role:button:提交"       → page.get_by_role('button', name='提交')
        "label:邮箱地址"         → page.get_by_label('邮箱地址')
        "text:欢迎回来"          → page.get_by_text('欢迎回来')
        "placeholder:请输入密码" → page.get_by_placeholder('请输入密码')
        "alt:公司Logo"           → page.get_by_alt_text('公司Logo')
        "title:关闭"             → page.get_by_title('关闭')
        "testid:submit-btn"      → page.get_by_test_id('submit-btn')
    """
    parts = description.split(":", 2)
    if len(parts) != 2:
        raise ValueError(f"格式错误，应为 'type:value'，收到: '{description}'")

    kind, value = parts

    mapping = {
        "role": lambda v: page.get_by_role(v.split(":")[0], name=v.split(":")[1] if ":" in v else None),
        "label": page.get_by_label,
        "text": page.get_by_text,
        "placeholder": page.get_by_placeholder,
        "alt": page.get_by_alt_text,
        "title": page.get_by_title,
        "testid": page.get_by_test_id,
    }

    if kind not in mapping:
        raise ValueError(f"不支持的定位器类型: '{kind}'，可选: {', '.join(mapping.keys())}")

    return mapping[kind](value)


def save_browser_state(context: BrowserContext, path: str = ".browser-state/state.json"):
    """保存浏览器状态（Cookie + LocalStorage）以便复用。"""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    state = context.storage_state()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    print(f"[browser-helper] 状态已保存到 {path}")


def load_browser_state(path: str = ".browser-state/state.json") -> dict | None:
    """加载已保存的浏览器状态。文件不存在时返回 None。"""
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def verify_and_screenshot(page: Page, text: str, screenshot_path: str):
    """验证页面包含指定文本并截图。"""
    expect(page.get_by_text(text)).to_be_visible(timeout=5000)
    os.makedirs(os.path.dirname(screenshot_path) or ".", exist_ok=True)
    page.screenshot(path=screenshot_path)
    print(f"[browser-helper] 验证通过: '{text}' → {screenshot_path}")
