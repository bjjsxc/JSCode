"""示例：复用已认证浏览器状态执行自动化任务。

演示如何保存和加载浏览器状态，避免重复登录。
"""

from playwright.sync_api import sync_playwright
from scripts.browser_helper import save_browser_state, load_browser_state, verify_and_screenshot


STATE_PATH = ".browser-state/authenticated.json"


def login_and_save_state():
    """首次登录并保存状态。"""
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context()
        page = context.new_page()

        page.goto("http://localhost:5173/login")
        page.wait_for_load_state("networkidle")

        page.get_by_label("邮箱").fill("admin@example.com")
        page.get_by_label("密码").fill("password123")
        page.get_by_role("button", name="登录").click()

        page.wait_for_url("**/dashboard")
        save_browser_state(context, STATE_PATH)
        print("[示例] 登录成功，状态已保存")
        browser.close()


def reuse_authenticated_session():
    """复用已保存的登录状态，无需重新登录。"""
    state = load_browser_state(STATE_PATH)
    if state is None:
        print("[示例] 无已保存状态，先执行登录")
        login_and_save_state()
        state = load_browser_state(STATE_PATH)

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(storage_state=state)
        page = context.new_page()

        page.goto("http://localhost:5173/dashboard")
        page.wait_for_load_state("networkidle")

        verify_and_screenshot(page, "欢迎", "screenshots/dashboard.png")
        print("[示例] 使用已认证会话访问仪表盘成功 ✓")
        browser.close()


if __name__ == "__main__":
    reuse_authenticated_session()
